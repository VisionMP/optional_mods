﻿--- Icons! ---

This Mod changes the loading/unloading icons into realistic ones. It also changes all activation Icons.

--- CREDITS

- SCS
- DaStrobel

--- KNOWN ISSUES
- Sometimes the Icons "disapear", because they are underneath the roads. That's caused because sometimes the icons are placed too low in the map editor or on prefabs. Sadly, I can't fix that.

Tested in 1.40.XX
Tested in 1.41.XX
Tested in 1.42.XX
Tested in 1.43.XX
Tested in 1.44.XX
Tested in 1.45.XX
Tested in 1.46.XX
Tested in 1.47.XX

[red]!!! DO NOT REUPLOAD, EDIT OR REDISTRIBUTE WITHOUT ORIGINAL LINK (STEAM) !!![red]
